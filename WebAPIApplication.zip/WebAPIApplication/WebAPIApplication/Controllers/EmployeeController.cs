﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPIApplication.Data;
using WebAPIApplication.Model;

namespace WebAPIApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly DataContext _context;

        public EmployeeController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<List<Employee>>> GetEmployee()
        {
            return Ok(await _context.Employees.ToListAsync());
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<List<Employee>>> GetEmployee(int id)
        {
            return Ok(await _context.Employees.FindAsync(id));
        }

        [HttpPost]
        public async Task<ActionResult<List<Employee>>> AddEmployee(Employee employee)
        {
            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();

            return Ok(await _context.Employees.ToListAsync());
        }

        [HttpPut]
        public async Task<ActionResult<List<Employee>>> UpdateEmployee(Employee request)
        {
            var dbEmp = await _context.Employees.FindAsync(request.Id);
            if (dbEmp == null)
            {
                return BadRequest("Employee not found.");
            }
            dbEmp.FirstName = request.FirstName;
            dbEmp.LastName = request.LastName;
            dbEmp.FullName = request.FullName;
            dbEmp.Phone = request.Phone;
            dbEmp.Email = request.Email;
            dbEmp.Salary = request.Salary;

            await _context.SaveChangesAsync();

            return Ok(await _context.Employees.ToListAsync());
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<List<Employee>>> Delete(int id)
        {
            var dbEmp = await _context.Employees.FindAsync(id);
            if (dbEmp == null)
                return BadRequest("Employee not found.");

            _context.Employees.Remove(dbEmp);
            await _context.SaveChangesAsync();

            return Ok(await _context.Employees.ToListAsync());
        }

    }
}
