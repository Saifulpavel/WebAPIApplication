﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIApplication.Repository.EmployeeSetup
{
    public interface IEmployee
    {

    }
}
